from djongo import models

class Bill(models.Model):
    user = models.CharField(max_length=100)
    bill_image = models.ImageField(upload_to="bills/")
    extracted_text = models.TextField(blank=True, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "bills"
